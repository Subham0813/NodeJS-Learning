const categories = [
  "Tech News",
  "General News",
  "Programming and Development",
  "Entertainment and Lifestyle",
  "Science and Education",
  "Finance and Business",
  "Sports"
  ]

export default categories
